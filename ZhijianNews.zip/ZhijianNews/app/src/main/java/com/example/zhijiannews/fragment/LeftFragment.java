package com.example.zhijiannews.fragment;

import android.view.View;

import com.example.zhijiannews.base.BaseFragment;

public class LeftFragment extends BaseFragment {
    @Override
    public View initView() {
        return null;
        
    }

    @Override
    public void initData() {
        super.initData();
    }
}
