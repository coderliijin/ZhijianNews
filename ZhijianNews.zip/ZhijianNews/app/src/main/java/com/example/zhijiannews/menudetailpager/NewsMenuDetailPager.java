package com.example.zhijiannews.menudetailpager;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;

import com.example.zhijiannews.R;
import com.example.zhijiannews.base.MenuDetailBasepager;
import com.example.zhijiannews.domain.NewsCenterPagerBean;
import com.example.zhijiannews.menudetailpager.tabdetailpager.TabDetailPager;
import com.example.zhijiannews.utils.LogUtil;

import org.xutils.view.annotation.ViewInject;
import org.xutils.x;

import java.util.ArrayList;
import java.util.List;

import androidx.annotation.NonNull;
import androidx.viewpager.widget.PagerAdapter;
import androidx.viewpager.widget.ViewPager;

public class NewsMenuDetailPager extends MenuDetailBasepager {

    @ViewInject(R.id.viewpager)
    private ViewPager viewPager;
    private List<NewsCenterPagerBean.DataBean.ChildrenBean> children;
    private List<TabDetailPager> tabDetailPagers;

    public NewsMenuDetailPager(Context context, NewsCenterPagerBean.DataBean dataBean) {

        super(context);
        children = dataBean.getChildren();
    }

    @Override
    public View initView() {
        View view = View.inflate(context, R.layout.newsmenu_detail_pager, null);
        x.view().inject(this, view);
        return view;
    }

    @Override
    public void initData() {
        LogUtil.e("新闻详情页面数据被初始化。。。");
        tabDetailPagers = new ArrayList<>();
        //准备新闻详情页面数据
        for (int i = 0; i < children.size(); i++) {
            TabDetailPager tabDetailPager = new TabDetailPager(context, children.get(i));
            tabDetailPagers.add(tabDetailPager);
        }
        //设置适配器
        viewPager.setAdapter(new myNewsMenuDetailPagerAdapter());

    }

    private class myNewsMenuDetailPagerAdapter extends PagerAdapter {
        @Override
        public int getCount() {
            return tabDetailPagers.size();
        }

        @Override
        public boolean isViewFromObject(@NonNull View view, @NonNull Object object) {
            return view == object;
        }

        @NonNull
        @Override
        public Object instantiateItem(@NonNull ViewGroup container, int position) {
            TabDetailPager tabDetailPager = tabDetailPagers.get(position);
            View rootview = tabDetailPager.rootview;
            tabDetailPager.initData();//初始化数据
            container.addView(rootview);
            return rootview;
        }

        @Override
        public void destroyItem(@NonNull ViewGroup container, int position, @NonNull Object object) {
            container.removeView((View) object);
        }
    }
}
