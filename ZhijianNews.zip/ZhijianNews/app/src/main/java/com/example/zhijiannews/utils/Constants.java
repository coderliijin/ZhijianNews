package com.example.zhijiannews.utils;

public class Constants {
    /*
    联网请求的ip和端口
     */
    public static final String BASE_URL = "http://b229v52627.imwork.net:25575/web_home";
    //快捷键ctrl+shift+U
    /*
    新闻中心的网络地址
     */
    public static final String NEWSCENTER_PAGER_URL = "http://b229v52627.imwork.net:25575/web_home/static/api/news/categories.json";
}
