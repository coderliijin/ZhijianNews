package com.example.zhijiannews.fragment;

import android.support.v4.view.ViewPager;
import android.view.View;

import com.example.zhijiannews.R;
import com.example.zhijiannews.base.BaseFragment;

import butterknife.BindView;

public class ContentFragment extends BaseFragment {

    @BindView(R.id.viewpager)
    ViewPager viewpager;
    

    @Override
    public View initView() {
        View view = View.inflate(context, R.layout.content_fragment, null);
       
        return view;

    }

    @Override
    public void initData() {
        super.initData();
    }

    

   
}
